package farmapp;

/**
 *FarmApp.java
 * @author Denise Balasmeh, Celina Moali, Safiat dao
 *  x24701351, x23160306, x23477232  
 */
public class FarmApp {

    public static void main(String[] args) {
        MainMenuGUI mainGUI = new MainMenuGUI();
        mainGUI.setVisible(true);
    }
    
}
