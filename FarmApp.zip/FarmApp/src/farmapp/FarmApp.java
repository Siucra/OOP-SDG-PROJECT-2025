/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package farmapp;

/**
 *FarmApp.java
 * @author
 */
public class FarmApp {

    public static void main(String[] args) {
        MainMenuGUI mainGUI = new MainMenuGUI();
        mainGUI.setVisible(true);
    }
    
}
